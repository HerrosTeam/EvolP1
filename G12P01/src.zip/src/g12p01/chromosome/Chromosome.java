/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g12p01.chromosome;

import g12p01.chromosome.gene.Gene;

/**
 *
 * @author usuario_local
 */
public class Chromosome {
    private Gene genes[];
    private int max;
    private int min;
    
    private int getLength(){
        int length = 0;
        for(Gene g: genes){
            length += g.getLength();
        }
        return length;
    }
    
   public double evaluate(){
       return 0;
   }
   
   public double fenotype(){
       return 0;
   }
    
}
